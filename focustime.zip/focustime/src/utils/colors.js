export const colors = {
  white: '#fff',
  maruBlue: '#0BC4E2',
  blueTeam: '#042028',
  maruBackGround: '#0A0E13',
  maruGold: '#D5B264',
  matuTextBox: '#56595B',
}